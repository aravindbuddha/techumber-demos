package MAP::API;
use Dancer;
use DBI;

# localhost:5000/country.json
get '/country.:format' => sub{
	my $format=param('format');
	my $database = "TU";
	my $user   = "sa";
	my $passwd = "abc123";
	my $server = ".\\DIMPU";
	# connect to database
    my $dbh = DBI->connect("DBI:ODBC:Driver={SQL Server};Server=$server;Database=$database;UID=$user;PWD=$passwd");
	
	my @rows;
	my $sql_str = "select *from Country";
	my $sth = $dbh->prepare($sql_str);
	$sth->execute();
	while ( my $record = $sth->fetchrow_hashref()) {
		push @rows,$record;
	}
	set_format($format);
	return {
		data => [@rows],
		status => 'success', 
		response => 'Succcess' 
	};
};
# setting output format based on extenction
sub set_format{
	my $format=shift;
	if ( defined($format) ) {
		if ( $format eq "json" ) {
			set serializer => 'JSON';
		} elsif ( $format eq "xml" ) {
			set serializer => 'XML';
		} elsif ( $format eq "yaml" ) {
			set serializer => 'YAML';
		} else {
			set serializer => 'JSON';
		}
	} else {
		set serializer => 'JSON';
	}
}


1;